export const layout = {
  topbar: {
    height: '30px',
  },
  sidebar: {
    width: '240px',
    collapsedWidth: '56px',
  },
  rightPanel: {
    defaultWidth: '320px',
  },
  bottomPanel: {
    minHeight: '100px',
    defaultHeight: '240px',
  },
} as const;
