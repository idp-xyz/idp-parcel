# Core Tokens

This folder contains raw design values (non-semantic):

- color scale
- spacing scale
- radius scale
- shadow scale
- typography scale
- motion values

Rules:

1. No product names.
2. No component names.
3. No semantic meaning like success/warning.
