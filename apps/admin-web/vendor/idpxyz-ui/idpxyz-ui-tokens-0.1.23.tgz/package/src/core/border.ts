/**
 * Core border width scale.
 */
export const coreBorderWidth = {
  none: '0px',
  hairline: '0.5px',
  sm: '1px',
  md: '2px',
} as const;
