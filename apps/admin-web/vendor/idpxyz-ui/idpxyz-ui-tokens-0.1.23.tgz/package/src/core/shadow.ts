/**
 * Core shadow (elevation) scale.
 */
export const coreShadow = {
  none: 'none',
  xs: '0 1px 2px rgba(0,0,0,0.18)',
  sm: '0 2px 6px rgba(0,0,0,0.2)',
  md: '0 6px 18px rgba(0,0,0,0.24)',
  lg: '0 10px 24px rgba(0,0,0,0.28)',
  xl: '0 14px 30px rgba(0,0,0,0.32)',
} as const;
