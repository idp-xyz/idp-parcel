# Product Overrides

This folder contains controlled product-level token overrides.

Rules:

1. Use only when semantic/theme layers cannot satisfy product branding.
2. Keep overrides minimal and documented.
3. Avoid changing structural spacing/typography defaults unless approved.
