/**
 * LOMS product-level token overrides.
 * Only values that genuinely differ from the shared theme belong here.
 */
export const lomsOverrides: Record<string, string> = {
  'product.accent': '#007acc',
  'product.accent.subtle': 'rgba(0,122,204,0.20)',
  'product.accent.fg': '#ffffff',
};
