/**
 * Prism product-level token overrides.
 * Only values that genuinely differ from the shared theme belong here.
 */
export const prismOverrides: Record<string, string> = {
  'product.accent': '#0891b2',
  'product.accent.subtle': 'rgba(8,145,178,0.18)',
  'product.accent.fg': '#ecfeff',
};
