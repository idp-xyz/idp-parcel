# Themes

This folder contains theme variants (light, dark, accessibility variants).

Rules:

1. Keep key set stable across themes.
2. Theme files override values, not token names.
