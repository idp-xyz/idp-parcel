/**
 * Semantic action & focus tokens.
 */
export const actionTokens = {
  dark: {
    'focus.ring': '#4ea1ff',
  },
  light: {
    'focus.ring': '#2563eb',
  },
} as const;
