/**
 * Semantic syntax highlight tokens.
 */
export const syntaxTokens = {
  dark: {
    'syntax.keyword': '#569cd6',
    'syntax.string': '#ce9178',
    'syntax.number': '#b5cea8',
    'syntax.comment': '#6a9955',
    'syntax.function': '#dcdcaa',
    'syntax.variable': '#9cdcfe',
    'syntax.type': '#4ec9b0',
    'syntax.tag': '#569cd6',
    'syntax.attribute': '#9cdcfe',
    'syntax.scrollbar': '#424242',
  },
  light: {
    'syntax.keyword': '#0000ff',
    'syntax.string': '#a31515',
    'syntax.number': '#098658',
    'syntax.comment': '#008000',
    'syntax.function': '#795e26',
    'syntax.variable': '#001080',
    'syntax.type': '#267f99',
    'syntax.tag': '#800000',
    'syntax.attribute': '#ff0000',
    'syntax.scrollbar': '#c1c1c1',
  },
} as const;
