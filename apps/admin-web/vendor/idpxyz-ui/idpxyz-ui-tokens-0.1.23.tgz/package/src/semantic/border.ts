/**
 * Semantic border tokens.
 */
export const borderTokens = {
  dark: {
    'border.default': '#3c3c3c',
    'border.subtle': '#323232',
    'border.strong': '#4a4a4a',
    'border.focus': '#4ea1ff',
  },
  light: {
    'border.default': '#d1d5db',
    'border.subtle': '#e5e7eb',
    'border.strong': '#c4c9d3',
    'border.focus': '#2563eb',
  },
} as const;
