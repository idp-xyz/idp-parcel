# Semantic Tokens

This folder maps core tokens into semantic usage tokens:

- text
- background
- border
- action
- status
- surface

Rules:

1. Components must consume semantic tokens first.
2. Do not directly couple semantic tokens to a specific app page.
