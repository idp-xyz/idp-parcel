/**
 * Status icons — used in badges, alerts, toasts, and state indicators.
 */
export {
  // Basic status
  CheckCircle2 as IconSuccess,
  CheckCircle as IconCheckCircle,
  AlertTriangle as IconWarning,
  XCircle as IconError,
  Info as IconInfo,
  MinusCircle as IconNeutral,
  Clock as IconPending,
  Loader2 as IconLoading,
  Ban as IconBlocked,
  PauseCircle as IconPaused,
  PlayCircle as IconActive,
  AlertCircle as IconAlertCircle,
  AlertOctagon as IconCritical,
  ShieldAlert as IconSecurityAlert,
  FileSearch as IconNotFound,
  DatabaseZap as IconEmpty,

  // Business lifecycle status
  CircleDot as IconDraft,
  SendHorizontal as IconSubmitted,
  ThumbsUp as IconApproved,
  ThumbsDown as IconRejected,
  Rocket as IconPublished,
  Archive as IconArchived,
  Trash2 as IconDeleted,
  RotateCcw as IconReverted,
  RefreshCcw as IconRetrying,
  Timer as IconExpired,
  CircleCheck as IconCompleted,
  CircleX as IconCancelled,
  CirclePause as IconOnHold,
  CirclePlay as IconInProgress,
  CircleArrowUp as IconEscalated,
  CircleArrowDown as IconDeescalated,
  Verified as IconVerified,
  Unplug as IconDisconnected,
  Wifi as IconConnected,
  WifiOff as IconOffline,
} from 'lucide-react';

export type { LucideIcon } from 'lucide-react';
