/**
 * System-level icons — used in workspace shell, navigation, and global UI.
 * Re-exported from Lucide with semantic aliases for a stable API surface.
 */
export {
  // Navigation & layout
  LayoutDashboard as IconDashboard,
  Search as IconSearch,
  Settings as IconSettings,
  Menu as IconMenu,
  PanelLeft as IconPanelLeft,
  PanelRight as IconPanelRight,
  PanelBottom as IconPanelBottom,
  Maximize2 as IconMaximize,
  Minimize2 as IconMinimize,
  X as IconClose,

  // User & auth
  User as IconUser,
  Users as IconUsers,
  Shield as IconShield,
  Lock as IconLock,
  LogOut as IconLogOut,

  // Theme
  Sun as IconSun,
  Moon as IconMoon,

  // Misc system
  Command as IconCommand,
  Terminal as IconTerminal,
  Bell as IconBell,
  HelpCircle as IconHelp,
  ExternalLink as IconExternalLink,
  ArrowUpRight as IconArrowUpRight,
  Copy as IconCopy,
  Download as IconDownload,
  Upload as IconUpload,
  RefreshCw as IconRefresh,
  MoreHorizontal as IconMoreH,
  MoreVertical as IconMoreV,
  Ellipsis as IconEllipsis,
  Save as IconSave,
  Check as IconCheck,
  Image as IconImage,
  Mail as IconMail,
  Link as IconLink,
  Archive as IconArchive,
  Timer as IconTimer,

  // Chevrons & arrows
  ChevronDown as IconChevronDown,
  ChevronUp as IconChevronUp,
  ChevronLeft as IconChevronLeft,
  ChevronRight as IconChevronRight,
  ChevronsLeft as IconChevronsLeft,
  ChevronsRight as IconChevronsRight,
  ArrowLeft as IconArrowLeft,
  ArrowRight as IconArrowRight,

  // View density
  Rows3 as IconRowsComfortable,
  Rows4 as IconRowsCompact,
  Columns3 as IconColumns,
  LayoutGrid as IconGrid,
  List as IconList,
  LayoutList as IconLayoutList,
  ListFilter as IconListFilter,
  Grid3X3 as IconGrid3X3,
  Percent as IconPercent,
  MoveUp as IconMoveUp,
  MoveDown as IconMoveDown,

  // Time & history
  Clock as IconClock,
  History as IconHistory,
  Calendar as IconCalendar,

  // Data & files
  FileText as IconFileText,
  FolderTree as IconFolderTree,
  Folder as IconFolder,
  FolderOpen as IconFolderOpen,
  Database as IconDatabase,
  Layers as IconLayers,
  Filter as IconFilter,
  ArrowUpDown as IconArrowUpDown,
  SortAsc as IconSortAsc,
  SortDesc as IconSortDesc,
  Star as IconStar,
  Eye as IconEye,
  EyeOff as IconEyeOff,
  Bookmark as IconBookmark,
  Pin as IconPin,
  Trash2 as IconTrash,
  Edit as IconEdit,
  Plus as IconPlus,
  Minus as IconMinus,
  Tag as IconTag,
  UserPlus as IconUserPlus,
  Play as IconPlay,
  Pause as IconPause,
  MessageSquare as IconMessage,
  Target as IconTarget,
  DollarSign as IconDollar,
  Hash as IconHash,
  Phone as IconPhone,

  // Editing actions
  Undo2 as IconUndo,
  Redo2 as IconRedo,
  ZoomIn as IconZoomIn,
  ZoomOut as IconZoomOut,
  Maximize as IconFullscreen,
  Minimize as IconExitFullscreen,
  Share2 as IconShare,
  Printer as IconPrint,
  BellRing as IconNotification,
} from 'lucide-react';
